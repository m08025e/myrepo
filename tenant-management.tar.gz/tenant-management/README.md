# 商社テナント管理 Ansible プロジェクト (Podman Pod 方式)

## 前提

| 項目 | 内容 |
|---|---|
| OS | RHEL 9 (SELinux: disabled) |
| コンテナランタイム | Podman |
| フロントエンド | Apache httpd (Playbook が自動インストール) |

## アーキテクチャ

```
Internet
    │ :80
    ▼
[ Apache httpd ]
    ├── shoshaA.example.com → 127.0.0.1:18080
    │       ↓
    │   [ shosha-A-pod ]
    │     ├── shosha-A-tomcat  :8080  ← JSP (MSSQL JDBC)
    │     └── shosha-A-mssql   :1433  ← SQL Server Express
    │
    └── shoshaB.example.com → 127.0.0.1:28080
            ↓
        [ shosha-B-pod ]
          ├── shosha-B-tomcat  :8080
          └── shosha-B-mssql   :1433
```

## 操作一覧

### テナント追加

```bash
cp tenants/shosha-A.yml tenants/shosha-C.yml
vi tenants/shosha-C.yml   # tenant_name / subdomain / tenant_host_port / mssql_sa_password を変更

ansible-playbook add_tenant.yml -i inventory/hosts.yml -e tenant_name=shosha-C
```

### デモアプリデプロイ

```bash
ansible-playbook deploy_app.yml -i inventory/hosts.yml -e tenant_name=shosha-A
```

デプロイ後: http://shoshaA.example.com/ でデータグリッドが表示されます。

### テナント削除

```bash
# データ保持
ansible-playbook delete_tenant.yml -i inventory/hosts.yml -e tenant_name=shosha-C

# データも完全削除
ansible-playbook delete_tenant.yml -i inventory/hosts.yml \
  -e tenant_name=shosha-C -e purge_data=true
```

## ディレクトリ構成

```
.
├── add_tenant.yml
├── delete_tenant.yml
├── deploy_app.yml
├── inventory/hosts.yml
├── group_vars/all.yml
├── tenants/
│   ├── shosha-A.yml
│   └── shosha-B.yml
└── roles/
    ├── tenant/
    │   ├── tasks/  (main / create / delete)
    │   ├── templates/tenant-vhost.conf.j2
    │   └── handlers/main.yml
    └── app/
        ├── tasks/main.yml
        └── templates/
            ├── web.xml.j2
            └── index.jsp.j2
```

## デモアプリの内容

- テーブル: `ShoshaDB.dbo.shosha_items`
  - id, item_code, item_name, category, price, stock, updated_at
- 初回デプロイ時にサンプルデータ10件を自動投入
- Bootstrap 5 + DataTables によるデータグリッド
  - カテゴリ別サマリーカード
  - ページング・検索・ソート対応

## ホストポート割り当て例

| テナント | tenant_host_port |
|---|---|
| shosha-A | 18080 |
| shosha-B | 28080 |
| shosha-C | 38080 |

## Kubernetes への移行

```bash
podman kube generate shosha-A-pod -f shosha-A-pod.yaml
kubectl apply -f shosha-A-pod.yaml
```

## 手動操作リファレンス

```bash
# Pod 一覧
podman pod ps

# ログ確認
podman logs shosha-A-tomcat
podman logs shosha-A-mssql

# MSSQL に接続
podman exec -it shosha-A-mssql \
  /opt/mssql-tools18/bin/sqlcmd -S localhost -U sa -P '<password>' -No -d ShoshaDB

# Pod 再起動
systemctl restart pod-shosha-A-pod.service
```
